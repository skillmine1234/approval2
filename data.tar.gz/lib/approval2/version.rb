module Approval2
  VERSION = "0.1.9"
end
