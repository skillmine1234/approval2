require "approval2/version"
require "approval2/controller_additions"
require "approval2/model_additions"
require 'approval2/active_record_adapter.rb'